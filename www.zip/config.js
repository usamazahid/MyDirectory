//add php controller name

//var base_url="http://192.168.1.31/Najeela/YP_website/Webservice/";
var base_url="http://mydirectory.co.in/Webservice/";